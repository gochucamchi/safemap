from app.api.missing_persons import router

__all__ = ["router"]
