import React, { useState, useEffect } from 'react';
import { View, StyleSheet, Alert, ActivityIndicator, Text } from 'react-native';
import MapView, { Marker, PROVIDER_GOOGLE } from 'react-native-maps';
import * as Location from 'expo-location';
import { api } from '../services/api';

export default function MapScreen() {
  const [location, setLocation] = useState(null);
  const [missingPersons, setMissingPersons] = useState([]);
  const [loading, setLoading] = useState(true);
  const [errorMsg, setErrorMsg] = useState(null);

  // 초기 위치 및 데이터 로드
  useEffect(() => {
    (async () => {
      // 위치 권한 요청
      let { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted') {
        setErrorMsg('위치 권한이 필요합니다.');
        setLoading(false);
        return;
      }

      try {
        // 현재 위치 가져오기
        let location = await Location.getCurrentPositionAsync({});
        setLocation({
          latitude: location.coords.latitude,
          longitude: location.coords.longitude,
          latitudeDelta: 0.1,
          longitudeDelta: 0.1,
        });

        // 실종자 데이터 가져오기
        const data = await api.getMissingPersons({ limit: 100 });
        setMissingPersons(data);
      } catch (error) {
        console.error('Error loading data:', error);
        setErrorMsg('데이터를 불러오는데 실패했습니다.');
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  // 마커 클릭 핸들러
  const handleMarkerPress = (person) => {
    Alert.alert(
      '실종 정보',
      `위치: ${person.location_address}\n날짜: ${new Date(person.missing_date).toLocaleDateString('ko-KR')}`,
      [{ text: '확인' }]
    );
  };

  if (loading) {
    return (
      <View style={styles.centered}>
        <ActivityIndicator size="large" color="#007AFF" />
        <Text style={styles.loadingText}>데이터 로딩 중...</Text>
      </View>
    );
  }

  if (errorMsg) {
    return (
      <View style={styles.centered}>
        <Text style={styles.errorText}>{errorMsg}</Text>
      </View>
    );
  }

  // 기본 위치 (서울)
  const defaultLocation = {
    latitude: 37.5665,
    longitude: 126.9780,
    latitudeDelta: 0.5,
    longitudeDelta: 0.5,
  };

  return (
    <View style={styles.container}>
      <MapView
        style={styles.map}
        provider={PROVIDER_GOOGLE}
        initialRegion={location || defaultLocation}
        showsUserLocation={true}
        showsMyLocationButton={true}
      >
        {/* 실종 사건 마커 */}
        {missingPersons.map((person) => {
          // 좌표가 있는 경우에만 마커 표시
          if (person.latitude && person.longitude) {
            return (
              <Marker
                key={person.id}
                coordinate={{
                  latitude: person.latitude,
                  longitude: person.longitude,
                }}
                title="실종 사건"
                description={person.location_address}
                pinColor="#FF3B30"
                onPress={() => handleMarkerPress(person)}
              />
            );
          }
          return null;
        })}
      </MapView>

      {/* 통계 정보 오버레이 */}
      <View style={styles.statsOverlay}>
        <Text style={styles.statsText}>
          총 실종 사건: {missingPersons.length}건
        </Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  map: {
    flex: 1,
  },
  centered: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#fff',
  },
  loadingText: {
    marginTop: 10,
    fontSize: 16,
    color: '#666',
  },
  errorText: {
    fontSize: 16,
    color: '#FF3B30',
    textAlign: 'center',
    paddingHorizontal: 20,
  },
  statsOverlay: {
    position: 'absolute',
    top: 50,
    left: 20,
    right: 20,
    backgroundColor: 'rgba(255, 255, 255, 0.95)',
    padding: 15,
    borderRadius: 10,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    elevation: 5,
  },
  statsText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
  },
});
