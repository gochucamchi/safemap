"""
SafeMap Backend Application
실종자 안전지도 백엔드 API
"""

__version__ = "0.1.0"
