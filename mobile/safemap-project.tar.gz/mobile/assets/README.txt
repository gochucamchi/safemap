Assets 폴더

이 폴더에는 앱 아이콘과 스플래시 이미지가 필요합니다.

필요한 파일:
- icon.png (1024x1024px)
- splash.png (1242x2436px)
- favicon.png (48x48px)

무료 아이콘 다운로드:
- https://www.flaticon.com
- https://icons8.com
- https://www.iconfinder.com

아이콘 생성 도구:
- https://www.appicon.co
- https://makeappicon.com

임시로 간단한 색상 이미지를 사용해도 됩니다.
Expo는 기본 아이콘을 제공하므로 당장 없어도 앱 실행에는 문제 없습니다.
